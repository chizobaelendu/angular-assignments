export interface eventInterface {
    id: number;
    heading?: string;
    type: string;
    description: string;
    date: string;
    modeOfLecture: string;
    duration: string;
    regFee: number; //The ternary operator (?) indicates that regFee property can be undefined (empty) during object creation.
    expectation?: string;
    buttonText: string;
    detailedDescription?: string;
    organizer?: string;
};
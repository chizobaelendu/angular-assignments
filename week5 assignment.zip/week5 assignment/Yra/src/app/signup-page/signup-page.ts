import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-signup-page',
  styleUrl: './signup-page.css',
  templateUrl: './signup-page.html',
})
export class SignupPage {}

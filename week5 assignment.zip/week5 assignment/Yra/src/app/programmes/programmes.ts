import { NgClass, TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [TitleCasePipe, RouterLink, NgClass],
  selector: 'app-programmes',
  styleUrl: './programmes.css',
  templateUrl: './programmes.html',
})

export class Programmes {
  
}

import { NgClass } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  imports: [NgClass],
  selector: 'app-footer-component',
  styleUrl: './footer-component.css',
  templateUrl: './footer-component.html',
})
export class FooterComponent {}

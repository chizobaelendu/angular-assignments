import { TitleCasePipe, NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [TitleCasePipe, RouterLink, NgClass],
  selector: 'app-about',
  styleUrl: './about.css',
  templateUrl: './about.html',
})

export class About {
  
}

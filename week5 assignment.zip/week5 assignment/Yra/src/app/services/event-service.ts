import { Service } from '@angular/core';
import { eventList } from '../eventList';

@Service()

export class EventService {
    eventList = eventList;

    findEventById(eventId: number): any {
        //Array.find() method returns the FIRST element in the array that meets (matches) the condition specified in the callback function, 
        //or undefined if there is NO element that meets the condition.
        const foundEvent = this.eventList.find((event)=> {
            return event.id === eventId;
        });
        return foundEvent;
    };

    //Array.filter() method returns a NEW array of element(s) that meet the condition specified in the callback function. 
    findEventsByTypeHeadingRegFee(type:string | null, heading:string | null, regFee: string | null) {
        const foundEvents = this.eventList.filter((event)=> {
            return (event.type === type) || (event.heading === heading) || (event.regFee === Number(regFee));
        });
        return foundEvents;
    };

};

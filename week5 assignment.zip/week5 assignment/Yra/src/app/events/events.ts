import { NgClass, TitleCasePipe, UpperCasePipe, NgStyle, CurrencyPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ParamMap, RouterLink } from '@angular/router';
import { eventList } from '../eventList';
//We can either use RouterLink attribute directive, or Router.navigate([path:string, id:number]) method to navigate from one component (page) to another.
//The former is implemented on the TEMPLATE of a component via <a> tag, 
//while the latter is implemented on the CLASS and it is used to add (integrate) PARAMETER(S) to a path.
//NOTE: Unlike Router.navigate() method, <a> tag have queryParams attribute directive through which we can add QUERY-PARAMETER(S) to routerLink.
import { Router } from '@angular/router';
//ActivatedRoute.queryParamMap returns Observable object which when subscribed to
//provides ParamsAsMap object through which we access path QUERY-PARAMETER(S).
import { ActivatedRoute } from '@angular/router';
import { EventService } from '../services/event-service';

@Component({
  imports: [UpperCasePipe, RouterLink, NgClass, TitleCasePipe, NgStyle, CurrencyPipe],
  selector: 'app-events',
  styleUrl: './events.css',
  templateUrl: './events.html',
})

//Angular hooks (e.g OnInit, OnDestroy, etc.) MUST be implemented before they are used.
export class Events implements OnInit {
  constructor(private router: Router, private  activatedRoute:  ActivatedRoute, private eventService: EventService) {}

  eventList = eventList;
  regFeeText:string = "Registration fee: "; 
  eventQueryText:string = "query event";

  ngOnInit(): void {
    //console.log(this.eventList);
  };

  goToEventDetailsPage(eventId: number) {
    //Router.navigate() method adds (integrates) the second element of the passed array as a PARAMETER to the path before navigating.
    this.router.navigate(["/event-details", eventId]);
  };

 
  //Data in an Observable object are accessed by either passing a callback function or an observer object as argument to subscribe() method.
  //Data are accessed through subscribe() direct callback function and through the next property of an observer object respectively. 
  //NOTE: The callback funtion approach MUST be implemented using arrow function syntax, and the observer object approach MUST also be implemented
  //using the correct syntax of object definition e.g {next: callback-function}.
  //Failure to use the right syntax in both approaches will result in compilation error.
  queryEventsByTypeHeadingRegFee() {
    this.activatedRoute.queryParamMap.subscribe({
      next: (ParamsAsMap)=> {
        const type = ParamsAsMap.get("type");
        const heading = ParamsAsMap.get("heading");
        const regFee = ParamsAsMap.get("regFee");
        const foundEvents = this.eventService.findEventsByTypeHeadingRegFee(type, heading, regFee);
        this.eventList = foundEvents;
      },
      error: (err)=> {
        console.log(err);
      },
      complete: ()=> {
        console.log("Completed");
      }
    });
  };



};

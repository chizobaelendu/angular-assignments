import { Component } from '@angular/core';
import { NgClass, NgStyle, TitleCasePipe } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  imports: [NgStyle, NgClass, TitleCasePipe, RouterLink],
  selector: 'app-nav-bar-component',
  styleUrl: './nav-bar-component.css',
  templateUrl: './nav-bar-component.html',
  standalone: true
})

export class NavBarComponent {
  navbarAboutText:string = "about";
  navbarprogrammesText:string = "programmes";
  navbarresourcesText:string = "resources";
  navbareventsText:string = "events";
  navbarMediaText:string = "media";
  navbarOpportunitiesText:string = "opportunities";
  navbarCommunityText:string = "community";
}

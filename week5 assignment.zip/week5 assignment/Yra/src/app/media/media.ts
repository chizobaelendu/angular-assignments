import { NgClass, TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [TitleCasePipe, RouterLink, NgClass],
  selector: 'app-media',
  styleUrl: './media.css',
  templateUrl: './media.html',
})

export class Media {
  
}

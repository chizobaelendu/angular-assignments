import { Routes } from '@angular/router';
//Import the route components
import { About } from './about/about';
import { Programmes } from './programmes/programmes';
import { Resources } from './resources/resources';
import { Events } from './events/events';
import { Media } from './media/media';
import { Opportunities } from './opportunities/opportunities';
import { Community } from './community/community';
import { HomePage } from './home-page/home-page';
import { EventDetails } from './event-details/event-details';
import { SignalLoginForm } from './signal-login-form/signal-login-form';

//Define (specify/set) the components' routes.
//NOTE: Angular does NOT support prefixing route path with forward-slash (/).
export const routes: Routes = [
    { path: "about", component: About },
    { path: "programmes", component: Programmes },
    { path: "resources", component: Resources },
    { path: "events", component: Events },
    { path: "media", component: Media },
    { path: "opportunities", component: Opportunities },
    { path: "community", component: Community },
    { path: "", component: HomePage },
    //Route path can contain parameter(s) and query-parameter(s) and both are readable (extractable).
    //Colon (:) indicates that a value is a parameter, 
    //while question-mark (?) indicates that a value is a query-parameter.
    { path: "event-details/:id", component: EventDetails },
    { path: "login", component: SignalLoginForm },
];


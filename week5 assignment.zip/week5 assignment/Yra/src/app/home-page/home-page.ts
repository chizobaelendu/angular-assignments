import { Component } from '@angular/core';
import { NavBarComponent } from '../nav-bar-component/nav-bar-component';
import { RouterLink } from '@angular/router';
import { NgClass } from '@angular/common';

@Component({
  imports: [NavBarComponent, RouterLink, NgClass],
  selector: 'app-home-page',
  styleUrl: './home-page.css',
  templateUrl: './home-page.html',
})

export class HomePage {}

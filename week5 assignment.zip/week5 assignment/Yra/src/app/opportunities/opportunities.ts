import { NgClass, TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [TitleCasePipe, RouterLink, NgClass],
  selector: 'app-opportunities',
  styleUrl: './opportunities.css',
  templateUrl: './opportunities.html',
})

export class Opportunities {
  navbarOpportunitiesText:string = "opportunities";
}

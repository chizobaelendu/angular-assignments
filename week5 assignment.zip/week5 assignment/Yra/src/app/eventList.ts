/* 
interface eventListInterface {
    id: number;
    heading: string;
    type: string;
    description: string;
    date: string;
    modeOfLecture: string;
    duration: string;
    regFee?: number; //The ternary operator (?) indicates that regFee property can be undefined (empty) during object creation.
    expectation: string;
    buttonText: string;
};
*/

import { eventInterface } from "./interfaces/event-interface";

//export keyword is used before declaration.
export let eventList:eventInterface[] = [
    {
        id: 1,
        heading: "bootcamp",
        type: "training",
        description: "yra global research bootcamp 2026",
        date: "20 Aug",
        modeOfLecture: "online",
        duration: "4 weeks",
        regFee: 15000,
        expectation: "",
        buttonText: "register now",
        detailedDescription: "Intensive research training designed to equip researchers with essential knowledge and practical skills from idea development to publication.",
        organizer: "YRA Programme"
    },
    {
        id: 2,
        heading: "slr",
        type: "seminar",
        description: "how to write a systematic literature review",
        date: "30 Aug",
        modeOfLecture: "online",
        duration: "1 day",
        regFee: 5000,
        expectation: "practical slr writing and publication session.",
        buttonText: "view details",
        detailedDescription: "Practical session on systematic literature review design, searching, screening, synthesis and publication.",
        organizer: "YRA Programme"
    },
    {
        id: 3,
        heading: "spss",
        type: "workshop",
        description: "data analysis with spss for researchers",
        date: "10 Sep",
        modeOfLecture: "online",
        duration: "2 days",
        regFee: 7500,
        expectation: "hands-on statistical analysis workshop.",
        buttonText: "view details",
        detailedDescription: "Hands-on workshop on selecting, running and interpreting common statistical analyses.",
        organizer: "YRA Programme"
    }
];

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SignalLoginForm } from './signal-login-form';

describe('SignalLoginForm', () => {
  let component: SignalLoginForm;
  let fixture: ComponentFixture<SignalLoginForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SignalLoginForm],
    }).compileComponents();

    fixture = TestBed.createComponent(SignalLoginForm);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { NgClass, TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [TitleCasePipe, RouterLink, NgClass],
  selector: 'app-resources',
  styleUrl: './resources.css',
  templateUrl: './resources.html',
})

export class Resources {
 
}

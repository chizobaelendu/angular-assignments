import { Component, OnInit, signal } from '@angular/core';
//ActivatedRoute.paramMap returns Observable object which when subscribed to
//provides ParamsAsMap object through which we access path PARAMETER(S).
import { ActivatedRoute } from '@angular/router';
import { eventInterface } from '../interfaces/event-interface';
import { EventService } from '../services/event-service';
import { CurrencyPipe, NgClass, NgStyle, TitleCasePipe, UpperCasePipe } from '@angular/common';

@Component({
  imports: [TitleCasePipe, UpperCasePipe, NgClass, NgStyle, CurrencyPipe],
  selector: 'app-event-details',
  styleUrl: './event-details.css',
  templateUrl: './event-details.html',
})

export class EventDetails implements OnInit {
  constructor(private activatedRoute: ActivatedRoute, private  eventService:  EventService) {}

  //Create signal property and initialize it with empty object. 
  event = signal<eventInterface>({} as eventInterface);
  regFeeText:string = "Registration fee";
  eventSignupButtonText:string = "Continue to registration & payment";

  /*
  //By default, Angular stores Data in Observable object and MUST be subscribed before the data can be accessed. 
  //Observable.subscribe() method takes in an object of three(3) properties as argument when called.
  displayPathParam() {
    this.activatedRoute.paramMap.subscribe({
      next: (ParamsAsMap)=> {
        //ParamsAsMap.get(pathParamName: string) method returns the value of the specified path parameter name (key) or null if it does NOT exist.
        //ParamsAsMap.getAll(pathParamName: string) method returns an array that contains the value of the specified path parameter name (key).
        console.log(ParamsAsMap.get("id"));
      },
      error: (err)=> {
        console.log(err);
      },
      complete: ()=> {
        console.log("Completed");
      }
    });
  };
  */

  findEventById() {
    this.activatedRoute.paramMap.subscribe({
      next: (ParamsAsMap)=> {
        //Parameter and query-parameter values are string data-type, hence the need to convert them to number data-type.
        const eventId = Number(ParamsAsMap.get("id"));
        const foundEvent = this.eventService.findEventById(eventId);
        //Update (change) the value of the signal property.
        this.event.set(foundEvent as any);
        //Signal is a function that returns its value when called.
        //console.log(this.event());
      },
      error: (err)=> {
        console.log(err);
      },
      complete: ()=> {
        console.log("Completed");
      }
    });
  };

  ngOnInit(): void {
    this.findEventById();
  };

};


import { NgClass, TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [TitleCasePipe, RouterLink, NgClass],
  selector: 'app-community',
  styleUrl: './community.css',
  templateUrl: './community.html',
})

export class Community {
  
}

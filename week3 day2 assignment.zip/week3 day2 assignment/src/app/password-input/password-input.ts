import { NgClass, TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { PasswordInputVerificationPipe } from '../custom-pipes/password-input-verification-pipe';
import { FormsModule } from '@angular/forms';

@Component({
  imports: [TitleCasePipe, NgClass, PasswordInputVerificationPipe, FormsModule],
  selector: 'app-password-input',
  styleUrl: './password-input.css',
  templateUrl: './password-input.html',
})

export class PasswordInput {
  passwordInputPlaceholder:string = "please enter your password";
  passwordInputWidth:number = 99;
  passwordInputHeight:number = 45;
  passwordInputValue:any = "";
}

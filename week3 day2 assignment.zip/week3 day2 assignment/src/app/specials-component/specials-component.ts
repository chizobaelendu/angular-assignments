import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-specials-component',
  styleUrl: './specials-component.css',
  templateUrl: './specials-component.html',
})

export class SpecialsComponent {
  categoryName:string = "specials";
  categoryUrl:string = "/products/specials/";
}

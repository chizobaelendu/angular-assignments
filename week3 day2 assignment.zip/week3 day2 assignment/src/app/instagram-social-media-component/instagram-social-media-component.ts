import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [ RouterLink, NgClass ],
  selector: 'app-instagram-social-media-component',
  styleUrl: './instagram-social-media-component.css',
  templateUrl: './instagram-social-media-component.html',
})

export class InstagramSocialMediaComponent {
  socialMediaName:string = "instragram";
  socialMediaUrl:string = "instagram.com";
}

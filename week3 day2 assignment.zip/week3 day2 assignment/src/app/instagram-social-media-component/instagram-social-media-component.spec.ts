import { ComponentFixture, TestBed } from '@angular/core/testing';
import { InstagramSocialMediaComponent } from './instagram-social-media-component';

describe('InstagramSocialMediaComponent', () => {
  let component: InstagramSocialMediaComponent;
  let fixture: ComponentFixture<InstagramSocialMediaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InstagramSocialMediaComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(InstagramSocialMediaComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

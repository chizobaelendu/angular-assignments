import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink, NgClass ],
  selector: 'app-laces-component',
  styleUrl: './laces-component.css',
  templateUrl: './laces-component.html',
})

export class LacesComponent {
  categoryName:string = "laces";
  categoryUrl:string = "/products/laces/";
}

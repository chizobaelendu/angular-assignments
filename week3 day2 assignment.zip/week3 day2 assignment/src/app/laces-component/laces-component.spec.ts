import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LacesComponent } from './laces-component';

describe('LacesComponent', () => {
  let component: LacesComponent;
  let fixture: ComponentFixture<LacesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LacesComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(LacesComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

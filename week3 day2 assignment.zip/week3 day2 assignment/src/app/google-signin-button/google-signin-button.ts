import { TitleCasePipe, NgClass } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  imports: [TitleCasePipe, NgClass],
  selector: 'app-google-signin-button',
  styleUrl: './google-signin-button.css',
  templateUrl: './google-signin-button.html',
})

export class GoogleSigninButton {
  googleSigninLinkText:string = "sign in using google";
}


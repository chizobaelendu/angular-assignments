import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-vlisco-component',
  styleUrl: './vlisco-component.css',
  templateUrl: './vlisco-component.html',
})

export class VliscoComponent {
  categoryName:string = "vlisco";
  categoryUrl:string = "/products/vlisco/";
}

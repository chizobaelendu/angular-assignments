import { ComponentFixture, TestBed } from '@angular/core/testing';
import { VliscoComponent } from './vlisco-component';

describe('VliscoComponent', () => {
  let component: VliscoComponent;
  let fixture: ComponentFixture<VliscoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VliscoComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(VliscoComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

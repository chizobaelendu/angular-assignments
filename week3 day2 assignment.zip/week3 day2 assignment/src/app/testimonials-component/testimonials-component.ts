import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-testimonials-component',
  styleUrl: './testimonials-component.css',
  templateUrl: './testimonials-component.html',
})

export class TestimonialsComponent {
  quickLinkName:string = "testimonials";
  quickLinkUrl:string = "/testimonials.html";
}

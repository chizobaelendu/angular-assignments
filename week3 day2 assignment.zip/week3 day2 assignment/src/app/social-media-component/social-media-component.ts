import { Component } from '@angular/core';
import { XSocialMediaComponent } from '../x-social-media-component/x-social-media-component';
import { FacebookSocialMediaComponent } from '../facebook-social-media-component/facebook-social-media-component';
import { PinterestSocialMediaComponent } from '../pinterest-social-media-component/pinterest-social-media-component';
import { InstagramSocialMediaComponent } from '../instagram-social-media-component/instagram-social-media-component';
import { UpperCasePipe } from '@angular/common';

@Component({
  imports: [ XSocialMediaComponent, FacebookSocialMediaComponent, PinterestSocialMediaComponent, InstagramSocialMediaComponent, UpperCasePipe ],
  selector: 'app-social-media-component',
  styleUrl: './social-media-component.css',
  templateUrl: './social-media-component.html',
})

export class SocialMediaComponent {
  componentTitle:string = "empire textiles";
}

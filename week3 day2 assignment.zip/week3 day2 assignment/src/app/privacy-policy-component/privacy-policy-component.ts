import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-privacy-policy-component',
  styleUrl: './privacy-policy-component.css',
  templateUrl: './privacy-policy-component.html',
})

export class PrivacyPolicyComponent {
  quickLinkName:string = "privacy policy";
  quickLinkUrl:string = "/privacy-policy.html";
}

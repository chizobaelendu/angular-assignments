import { NgClass, TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { EmailInputVerificationPipe } from '../custom-pipes/email-input-verification-pipe';
import { FormsModule } from '@angular/forms';

//interface userInterface {
  //email:string
//}

//NOTE: A class decorator MUST be placed DIRECTLY before the class declaration as Typescript does NOT support
//a situation where code is written in-between a decorator and the class declaration.
@Component({
  imports: [TitleCasePipe, NgClass, EmailInputVerificationPipe, FormsModule],
  selector: 'app-email-input',
  styleUrl: './email-input.css',
  templateUrl: './email-input.html',
})

export class EmailInput {
  emailInputPlaceholder:string = "please type your email address";
  emailInputWidth:number = 99;
  emailInputHeight:number = 45;
  emailInputValue:any = "";

  //user:userInterface = {
    //email: "i-am-a-good-programmer@gmail.com"
  //};
}

import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-terms-and-conditions-component',
  styleUrl: './terms-and-conditions-component.css',
  templateUrl: './terms-and-conditions-component.html',
})

export class TermsAndConditionsComponent {
  quickLinkName:string = "terms & conditions";
  quickLinkUrl:string = "/terms-and-conditions.html";
}

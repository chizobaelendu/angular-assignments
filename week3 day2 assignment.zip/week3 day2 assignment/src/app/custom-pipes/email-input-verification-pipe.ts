import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'emailInputVerification',
})

export class EmailInputVerificationPipe implements PipeTransform {
  transform(inputValue:any): any {
    if (inputValue === "" || inputValue === undefined || inputValue === null) {
      return "Cannot be empty, provide your email address";
    } else {
      return inputValue;
    };
  };

};

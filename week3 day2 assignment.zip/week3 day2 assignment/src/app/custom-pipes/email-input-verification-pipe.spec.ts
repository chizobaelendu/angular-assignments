import { EmailInputVerificationPipe } from './email-input-verification-pipe';

describe('EmailInputVerificationPipe', () => {
  it('create an instance', () => {
    const pipe = new EmailInputVerificationPipe();
    expect(pipe).toBeTruthy();
  });
});

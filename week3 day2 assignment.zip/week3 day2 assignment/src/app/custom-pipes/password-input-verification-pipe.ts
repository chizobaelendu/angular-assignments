import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'passwordInputVerification',
})

export class PasswordInputVerificationPipe implements PipeTransform {
  transform(inputValue:any): any {
    if (inputValue === "" || inputValue === undefined || inputValue === null) {
      return "Cannot be empty, provide your password";
    } else {
      return "";
    };
  };
};

import { PasswordInputVerificationPipe } from './password-input-verification-pipe';

describe('PasswordInputVerificationPipe', () => {
  it('create an instance', () => {
    const pipe = new PasswordInputVerificationPipe();
    expect(pipe).toBeTruthy();
  });
});

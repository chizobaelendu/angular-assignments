import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-blog-component',
  styleUrl: './blog-component.css',
  templateUrl: './blog-component.html',
})

export class BlogComponent {
  quickLinkName:string = "blog";
  quickLinkUrl:string = "/blog";
}

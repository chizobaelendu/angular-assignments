import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-contact-us-component',
  styleUrl: './contact-us-component.css',
  templateUrl: './contact-us-component.html',
})

export class ContactUsComponent {
  quickLinkName:string = "contact us";
  quickLinkUrl:string = "/contact-us.html";
}

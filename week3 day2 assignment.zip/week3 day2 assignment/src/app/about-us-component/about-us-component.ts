import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-about-us-component',
  styleUrl: './about-us-component.css',
  templateUrl: './about-us-component.html',
})

export class AboutUsComponent {
  quickLinkName:string = "About Empire Textiles";
  quickLinkUrl:string = "/about-us.html";
}

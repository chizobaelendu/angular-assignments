import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-shoes-and-bags-component',
  styleUrl: './shoes-and-bags-component.css',
  templateUrl: './shoes-and-bags-component.html',
})

export class ShoesAndBagsComponent {
  categoryName:string = "shoes & bags";
  categoryUrl:string = "/products/shoes-and-bags/";
}

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ShoesAndBagsComponent } from './shoes-and-bags-component';

describe('ShoesAndBagsComponent', () => {
  let component: ShoesAndBagsComponent;
  let fixture: ComponentFixture<ShoesAndBagsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShoesAndBagsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ShoesAndBagsComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

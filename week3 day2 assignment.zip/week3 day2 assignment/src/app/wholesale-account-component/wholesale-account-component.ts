import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-wholesale-account-component',
  styleUrl: './wholesale-account-component.css',
  templateUrl: './wholesale-account-component.html',
})

export class WholesaleAccountComponent {
  quickLinkName:string = "create wholesale account";
  quickLinkUrl:string = "/wholesale.html";
}

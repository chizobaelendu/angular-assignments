import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WholesaleAccountComponent } from './wholesale-account-component';

describe('WholesaleAccountComponent', () => {
  let component: WholesaleAccountComponent;
  let fixture: ComponentFixture<WholesaleAccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WholesaleAccountComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(WholesaleAccountComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { CategoriesComponent } from '../categories-component/categories-component';
import { QuickLinksComponent } from '../quick-links-component/quick-links-component';
import { NgClass } from '@angular/common';

@Component({
  imports: [CategoriesComponent, QuickLinksComponent, NgClass],
  selector: 'app-categories-and-quicklinks-component',
  styleUrl: './categories-and-quicklinks-component.css',
  templateUrl: './categories-and-quicklinks-component.html',
})

export class CategoriesAndQuicklinksComponent {}

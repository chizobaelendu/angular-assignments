import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CategoriesAndQuicklinksComponent } from './categories-and-quicklinks-component';

describe('CategoriesAndQuicklinksComponent', () => {
  let component: CategoriesAndQuicklinksComponent;
  let fixture: ComponentFixture<CategoriesAndQuicklinksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CategoriesAndQuicklinksComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(CategoriesAndQuicklinksComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { NgClass, TitleCasePipe, UpperCasePipe, NgStyle } from '@angular/common';
import { Component } from '@angular/core';
import { EmailInput } from '../email-input/email-input';
import { PasswordInput } from '../password-input/password-input';
import { LoginButton } from '../login-button/login-button';
import { GoogleSigninButton } from '../google-signin-button/google-signin-button';
import { MicrosoftSigninButton } from '../microsoft-signin-button/microsoft-signin-button';
import { AppleSigninButton } from '../apple-signin-button/apple-signin-button';
import { RouterLink } from '@angular/router';

@Component({
  imports: [TitleCasePipe, UpperCasePipe, EmailInput, PasswordInput, LoginButton, GoogleSigninButton, MicrosoftSigninButton, AppleSigninButton, NgClass, NgStyle, RouterLink],
  selector: 'app-login-form',
  styleUrl: './login-form.css',
  templateUrl: './login-form.html',
})

export class LoginForm {
  formTitle:string = "my account";
  passwordResetLink:string = "forgetten your password";
  altLoginMethod:string = "-or-";
  textColor:string = "rgb(191, 21, 21)";
  isMouseEntered:boolean = false;

  //We can alternatively define separate functions that change the color of the text when mouse enters and leaves.
  //We can as well use ternary operator to implement if-else condition. 
  changeTextColorOnMouseEntranceAndLeave() {
    this.isMouseEntered = !this.isMouseEntered;
    if (this.isMouseEntered) {
      this.textColor = "black";
    } else {
      this.textColor = "rgb(191, 21, 21)";
    }
  };  

};

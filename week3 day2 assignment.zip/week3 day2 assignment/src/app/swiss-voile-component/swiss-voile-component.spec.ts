import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SwissVoileComponent } from './swiss-voile-component';

describe('SwissVoileComponent', () => {
  let component: SwissVoileComponent;
  let fixture: ComponentFixture<SwissVoileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SwissVoileComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(SwissVoileComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

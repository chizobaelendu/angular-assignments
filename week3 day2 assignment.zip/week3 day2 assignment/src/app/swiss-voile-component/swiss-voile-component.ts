import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-swiss-voile-component',
  styleUrl: './swiss-voile-component.css',
  templateUrl: './swiss-voile-component.html',
})

export class SwissVoileComponent {
  categoryName:string = "swiss voile";
  categoryUrl:string = "/products/swiss-voile/";
}

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FacebookSocialMediaComponent } from './facebook-social-media-component';

describe('FacebookSocialMediaComponent', () => {
  let component: FacebookSocialMediaComponent;
  let fixture: ComponentFixture<FacebookSocialMediaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FacebookSocialMediaComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(FacebookSocialMediaComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

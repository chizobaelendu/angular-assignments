import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [ RouterLink, NgClass ],
  selector: 'app-facebook-social-media-component',
  styleUrl: './facebook-social-media-component.css',
  templateUrl: './facebook-social-media-component.html',
})

export class FacebookSocialMediaComponent {
  socialMediaName:string = "facebook";
  socialMediaUrl:string = "facebook.com";
}

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PinterestSocialMediaComponent } from './pinterest-social-media-component';

describe('PinterestSocialMediaComponent', () => {
  let component: PinterestSocialMediaComponent;
  let fixture: ComponentFixture<PinterestSocialMediaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PinterestSocialMediaComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(PinterestSocialMediaComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

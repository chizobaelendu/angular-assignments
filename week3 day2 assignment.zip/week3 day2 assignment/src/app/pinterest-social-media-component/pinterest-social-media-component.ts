import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [ RouterLink, NgClass ],
  selector: 'app-pinterest-social-media-component',
  styleUrl: './pinterest-social-media-component.css',
  templateUrl: './pinterest-social-media-component.html',
})

export class PinterestSocialMediaComponent {
  socialMediaName:string = "pinterest";
  socialMediaUrl:string = "pinterest.com";
}

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MicrosoftSigninButton } from './microsoft-signin-button';

describe('MicrosoftSigninButton', () => {
  let component: MicrosoftSigninButton;
  let fixture: ComponentFixture<MicrosoftSigninButton>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MicrosoftSigninButton],
    }).compileComponents();

    fixture = TestBed.createComponent(MicrosoftSigninButton);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

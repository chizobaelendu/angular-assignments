import { NgClass, TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  imports: [TitleCasePipe, NgClass],
  selector: 'app-microsoft-signin-button',
  styleUrl: './microsoft-signin-button.css',
  templateUrl: './microsoft-signin-button.html',
})

export class MicrosoftSigninButton {
  microsoftSigninLinkText:string = "sign in using microsoft";
}

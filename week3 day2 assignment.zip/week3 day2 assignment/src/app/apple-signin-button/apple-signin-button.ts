import { NgClass, TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  imports: [TitleCasePipe, NgClass],
  selector: 'app-apple-signin-button',
  styleUrl: './apple-signin-button.css',
  templateUrl: './apple-signin-button.html',
})

export class AppleSigninButton {
  appleSigninLinkText:string = "sign in using apple";
}

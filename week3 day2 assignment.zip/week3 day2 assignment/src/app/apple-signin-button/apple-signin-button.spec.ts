import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AppleSigninButton } from './apple-signin-button';

describe('AppleSigninButton', () => {
  let component: AppleSigninButton;
  let fixture: ComponentFixture<AppleSigninButton>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppleSigninButton],
    }).compileComponents();

    fixture = TestBed.createComponent(AppleSigninButton);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

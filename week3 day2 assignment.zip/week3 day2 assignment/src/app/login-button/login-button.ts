import { NgClass, TitleCasePipe, UpperCasePipe, NgStyle } from '@angular/common';
import { Component } from '@angular/core';


@Component({
  imports: [TitleCasePipe, NgClass, UpperCasePipe, NgStyle],
  selector: 'app-login-button',
  styleUrl: './login-button.css',
  templateUrl: './login-button.html',
})

export class LoginButton {
  loginButtonText:string = "log in";
  backgroundColor:string = "rgb(191, 21, 21)";
  isMouseEntered:boolean = false;

  //We can alternatively define separate functions that change the background color of the button when mouse enters and leaves.
  //We can as well use ternary operator to implement if-else condition. 
  changeBackgroundColorOnMouseEnterAndLeave(red:string, darkRed:string) {
    this.isMouseEntered = !this.isMouseEntered;
    this.backgroundColor = this.isMouseEntered ? darkRed : red;
  };
};

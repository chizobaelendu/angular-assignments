import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-uniforms-component',
  styleUrl: './uniforms-component.css',
  templateUrl: './uniforms-component.html',
})

export class UniformsComponent {
  quickLinkName:string = "uniforms";
  quickLinkUrl:string = "/uniforms.html";
}

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UniformsComponent } from './uniforms-component';

describe('UniformsComponent', () => {
  let component: UniformsComponent;
  let fixture: ComponentFixture<UniformsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UniformsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(UniformsComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

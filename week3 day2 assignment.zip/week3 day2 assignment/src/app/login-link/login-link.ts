import { TitleCasePipe, UpperCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink, TitleCasePipe ],
  selector: 'app-login-link',
  styleUrl: './login-link.css',
  templateUrl: './login-link.html',
})

export class LoginLink {
  linkText:string = "login";
}

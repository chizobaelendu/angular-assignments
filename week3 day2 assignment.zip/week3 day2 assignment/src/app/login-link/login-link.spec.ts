import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginLink } from './login-link';

describe('LoginLink', () => {
  let component: LoginLink;
  let fixture: ComponentFixture<LoginLink>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LoginLink],
    }).compileComponents();

    fixture = TestBed.createComponent(LoginLink);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

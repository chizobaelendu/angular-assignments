import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink, NgClass],
  selector: 'app-wax-prints-component',
  styleUrl: './wax-prints-component.css',
  templateUrl: './wax-prints-component.html',
})

export class WaxPrintsComponent {
  categoryName:string = "wax prints";
  categoryUrl:string = "/products/wax-prints/";
}

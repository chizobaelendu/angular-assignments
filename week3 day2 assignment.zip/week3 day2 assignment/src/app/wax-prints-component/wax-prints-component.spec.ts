import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WaxPrintsComponent } from './wax-prints-component';

describe('WaxPrintsComponent', () => {
  let component: WaxPrintsComponent;
  let fixture: ComponentFixture<WaxPrintsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WaxPrintsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(WaxPrintsComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

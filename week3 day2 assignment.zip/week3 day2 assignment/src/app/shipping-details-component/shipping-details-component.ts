import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-shipping-details-component',
  styleUrl: './shipping-details-component.css',
  templateUrl: './shipping-details-component.html',
})

export class ShippingDetailsComponent {
  quickLinkName:string = "shipping details";
  quickLinkUrl:string = "/shipping.html";
}

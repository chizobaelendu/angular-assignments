import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ShippingDetailsComponent } from './shipping-details-component';

describe('ShippingDetailsComponent', () => {
  let component: ShippingDetailsComponent;
  let fixture: ComponentFixture<ShippingDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShippingDetailsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ShippingDetailsComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { LacesComponent } from '../laces-component/laces-component';
import { WaxPrintsComponent } from '../wax-prints-component/wax-prints-component';
import { ShoesAndBagsComponent } from '../shoes-and-bags-component/shoes-and-bags-component';
import { VliscoComponent } from '../vlisco-component/vlisco-component';
import { GetznerComponent } from '../getzner-component/getzner-component';
import { SwissVoileComponent } from '../swiss-voile-component/swiss-voile-component';
import { HeadGearComponent } from '../head-gear-component/head-gear-component';
import { BrocadeComponent } from '../brocade-component/brocade-component';
import { SpecialsComponent } from '../specials-component/specials-component';
import { NgClass, UpperCasePipe } from '@angular/common';

@Component({
  imports: [ LacesComponent, WaxPrintsComponent, ShoesAndBagsComponent, VliscoComponent, GetznerComponent, SwissVoileComponent, HeadGearComponent, BrocadeComponent, SpecialsComponent, NgClass, UpperCasePipe ],
  selector: 'app-categories-component',
  styleUrl: './categories-component.css',
  templateUrl: './categories-component.html',
})

export class CategoriesComponent {
  componentTitle:string = "categories";
}

/*
categoryName:string = "";
  categoryUrl:string = "";
  categories:categoryInterface[] = [
    {
      name: "laces",
      url: "laces.com"
    },
    {
      name: "wax prints",
      url: "wax-prints.com"
    },
    {
      name: "shoes & bags",
      url: "shoes-and-bags.com" //laces-component wax-prints-component shoes-and-bags-component vlisco-component getzner-component swiss-voile-component head-gear-component brocade-component specials-component   
    },
    {
      name: "vlisco",
      url: "vlisco.com"
    },
    {
      name: "getzner",
      url: "getzner.com"
    },
    {
      name: "swiss voile",
      url: "swiss-voile.com"
    },
    {
      name: "head gear",
      url: "head-gear.com"
    },
    {
      name: "brocade",
      url: "brocade.com"
    },
    {
      name: "specials",
      url: "specials.com"
    }
  ];
  */
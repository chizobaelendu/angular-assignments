import { Component } from '@angular/core';
import { AboutUsComponent } from '../about-us-component/about-us-component';
import { ContactUsComponent } from '../contact-us-component/contact-us-component';
import { TestimonialsComponent } from '../testimonials-component/testimonials-component';
import { FaqComponent } from '../faq-component/faq-component';
import { ShippingDetailsComponent } from '../shipping-details-component/shipping-details-component';
import { UniformsComponent } from '../uniforms-component/uniforms-component';
import { BlogComponent } from '../blog-component/blog-component';
import { WholesaleAccountComponent } from '../wholesale-account-component/wholesale-account-component';
import { TermsAndConditionsComponent } from '../terms-and-conditions-component/terms-and-conditions-component';
import { PrivacyPolicyComponent } from '../privacy-policy-component/privacy-policy-component';
import { UpperCasePipe } from '@angular/common';


@Component({
  imports: [ AboutUsComponent, ContactUsComponent, TestimonialsComponent, FaqComponent, ShippingDetailsComponent, UniformsComponent, BlogComponent, WholesaleAccountComponent, TermsAndConditionsComponent, PrivacyPolicyComponent, UpperCasePipe ],
  selector: 'app-quick-links-component',
  styleUrl: './quick-links-component.css',
  templateUrl: './quick-links-component.html',
})

export class QuickLinksComponent {
  componentTitle:string = "quick links";
}

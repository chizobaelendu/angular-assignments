import { Component } from '@angular/core';
import { SocialMediaComponent } from "../social-media-component/social-media-component";
//import { CategoriesComponent } from "../categories-component/categories-component";
//import { QuickLinksComponent } from '../quick-links-component/quick-links-component';
import { NewsletterComponent } from '../newsletter-component/newsletter-component';
import { CategoriesAndQuicklinksComponent } from '../categories-and-quicklinks-component/categories-and-quicklinks-component';
import { NgClass } from '@angular/common';

@Component({
  imports: [ SocialMediaComponent, NewsletterComponent, CategoriesAndQuicklinksComponent, NgClass ],
  selector: 'app-upper-footer-component',
  styleUrl: './upper-footer-component.css',
  templateUrl: './upper-footer-component.html',
})

export class UpperFooterComponent {}

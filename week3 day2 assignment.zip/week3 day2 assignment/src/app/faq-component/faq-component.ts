import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-faq-component',
  styleUrl: './faq-component.css',
  templateUrl: './faq-component.html',
})

export class FaqComponent {
  quickLinkName:string = "faq's";
  quickLinkUrl:string = "/faq.html";
}

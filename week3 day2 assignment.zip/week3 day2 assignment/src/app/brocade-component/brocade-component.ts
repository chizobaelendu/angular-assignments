import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-brocade-component',
  styleUrl: './brocade-component.css',
  templateUrl: './brocade-component.html',
})

export class BrocadeComponent {
  categoryName:string = "brocade";
  categoryUrl:string = "/products/brocade/";
}

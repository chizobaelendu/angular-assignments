import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BrocadeComponent } from './brocade-component';

describe('BrocadeComponent', () => {
  let component: BrocadeComponent;
  let fixture: ComponentFixture<BrocadeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BrocadeComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(BrocadeComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

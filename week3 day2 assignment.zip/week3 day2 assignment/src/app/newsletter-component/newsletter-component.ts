import { NgClass, NgStyle, UpperCasePipe } from '@angular/common';
import { TmplAstDeferredBlockPlaceholder } from '@angular/compiler';
import { Component } from '@angular/core';

@Component({
  imports: [NgClass, NgStyle, UpperCasePipe],
  selector: 'app-newsletter-component',
  styleUrl: './newsletter-component.css',
  templateUrl: './newsletter-component.html',
})

export class NewsletterComponent {
  componentTitle:string = "get the newsletter";
  newsletterPlaceholder:string = "enter email address";
  newsletterButtonText:string = "subscribe";
}

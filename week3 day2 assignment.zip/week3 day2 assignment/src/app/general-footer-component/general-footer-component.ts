import { Component } from '@angular/core';
import { UpperFooterComponent } from '../upper-footer-component/upper-footer-component';
import { NgClass } from '@angular/common';

@Component({
  imports: [ UpperFooterComponent, NgClass ],
  selector: 'app-general-footer-component',
  styleUrl: './general-footer-component.css',
  templateUrl: './general-footer-component.html',
})

export class GeneralFooterComponent {}

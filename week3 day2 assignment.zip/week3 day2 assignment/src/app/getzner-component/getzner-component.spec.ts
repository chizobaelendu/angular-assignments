import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GetznerComponent } from './getzner-component';

describe('GetznerComponent', () => {
  let component: GetznerComponent;
  let fixture: ComponentFixture<GetznerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GetznerComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(GetznerComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

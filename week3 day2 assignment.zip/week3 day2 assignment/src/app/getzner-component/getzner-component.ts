import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-getzner-component',
  styleUrl: './getzner-component.css',
  templateUrl: './getzner-component.html',
})

export class GetznerComponent {
  categoryName:string = "getzner";
  categoryUrl:string = "/products/getzner/";
}

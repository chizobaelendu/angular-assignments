import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [RouterLink],
  selector: 'app-head-gear-component',
  styleUrl: './head-gear-component.css',
  templateUrl: './head-gear-component.html',
})

export class HeadGearComponent {
  categoryName:string = "head gear";
  categoryUrl:string = "/products/head-gear/";
}

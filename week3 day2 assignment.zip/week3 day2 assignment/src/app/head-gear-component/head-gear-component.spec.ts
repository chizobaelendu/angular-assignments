import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HeadGearComponent } from './head-gear-component';

describe('HeadGearComponent', () => {
  let component: HeadGearComponent;
  let fixture: ComponentFixture<HeadGearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HeadGearComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(HeadGearComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

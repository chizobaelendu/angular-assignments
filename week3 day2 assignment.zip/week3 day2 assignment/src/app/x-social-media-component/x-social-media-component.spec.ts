import { ComponentFixture, TestBed } from '@angular/core/testing';
import { XSocialMediaComponent } from './x-social-media-component';

describe('XSocialMediaComponent', () => {
  let component: XSocialMediaComponent;
  let fixture: ComponentFixture<XSocialMediaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [XSocialMediaComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(XSocialMediaComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

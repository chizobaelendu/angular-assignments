import { NgClass } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  imports: [ RouterLink, NgClass ],
  selector: 'app-x-social-media-component',
  styleUrl: './x-social-media-component.css',
  templateUrl: './x-social-media-component.html',
})

export class XSocialMediaComponent {
  socialMediaName:string = "x";
  socialMediaUrl:string = "x.com";
}

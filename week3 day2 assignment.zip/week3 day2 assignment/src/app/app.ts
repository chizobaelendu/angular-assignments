import { Component, signal } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { GeneralFooterComponent } from './general-footer-component/general-footer-component';
import { LoginLink } from './login-link/login-link';
import { LoginForm } from './login-form/login-form';

@Component({
  imports: [ RouterOutlet, GeneralFooterComponent, RouterLink, LoginLink, LoginForm ],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})

export class App {

};
